"""
SQLAlchemy ORM models for Finance Advisor.

These are the persistence-layer database models (User, FinancialRecord,
PredictionHistory, Goal). Not to be confused with the trained ML model
files stored under /models on disk.
"""
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class User(db.Model):
    __tablename__ = "user"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=True)
    college = db.Column(db.String(200), nullable=True)
    location = db.Column(db.String(120), nullable=True)
    monthly_income = db.Column(db.Float, default=0.0)
    currency = db.Column(db.String(10), default="INR (₹)")

    # Preferences
    theme = db.Column(db.String(20), default="Light")
    expense_reminder = db.Column(db.Boolean, default=True)
    goal_notifications = db.Column(db.Boolean, default=True)
    email_updates = db.Column(db.Boolean, default=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    financial_records = db.relationship("FinancialRecord", backref="user", lazy=True)
    predictions = db.relationship("PredictionHistory", backref="user", lazy=True)
    goals = db.relationship("Goal", backref="user", lazy=True)


class FinancialRecord(db.Model):
    __tablename__ = "financial_record"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow)

    income = db.Column(db.Float, nullable=False)
    food_expense = db.Column(db.Float, default=0.0)
    shopping_expense = db.Column(db.Float, default=0.0)
    transport_expense = db.Column(db.Float, default=0.0)
    bills = db.Column(db.Float, default=0.0)
    entertainment = db.Column(db.Float, default=0.0)
    other_expense = db.Column(db.Float, default=0.0)

    total_expense = db.Column(db.Float, default=0.0)
    savings = db.Column(db.Float, default=0.0)
    debt = db.Column(db.Float, default=0.0)


class PredictionHistory(db.Model):
    __tablename__ = "prediction_history"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    prediction_type = db.Column(db.String(50), nullable=False)  # Expense Prediction / Financial Status / Goal Planner
    input_summary = db.Column(db.String(255), nullable=False)
    input_data = db.Column(db.Text, nullable=True)  # JSON string of full inputs
    result = db.Column(db.String(255), nullable=False)
    result_data = db.Column(db.Text, nullable=True)  # JSON string of full result payload
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Goal(db.Model):
    __tablename__ = "goal"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    goal_amount = db.Column(db.Float, nullable=False)
    target_months = db.Column(db.Integer, nullable=False)
    required_monthly_saving = db.Column(db.Float, nullable=False)
    current_monthly_saving = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50), nullable=False)  # Achievable / Not Achievable
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
