"""
train_models.py
----------------
Trains the two core ML models for Finance Advisor:

1. Regression  -> RandomForestRegressor: predicts next-month total expense
2. Classification -> RandomForestClassifier: predicts financial health
   (Healthy / Moderate / Risky)

Both models are evaluated with real train/test metrics (no fabricated
numbers) and saved with Joblib, alongside a small JSON metadata file
containing feature names, feature importances, and evaluation metrics so
the Flask app can display genuine model-derived information.

Run:  python train_models.py
"""
import os
import json

import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    mean_absolute_error, mean_squared_error, r2_score,
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix,
)

from config import Config
from generate_dataset import generate_expense_dataset, generate_financial_health_dataset

REGRESSION_FEATURES = [
    "income", "food_expense", "shopping_expense", "transport_expense",
    "bills", "entertainment", "other_expense", "previous_total_expense",
]
REGRESSION_TARGET = "next_month_expense"

CLASSIFICATION_FEATURES = [
    "income", "total_expense", "savings", "debt", "savings_percentage",
]
CLASSIFICATION_TARGET = "financial_status"


def load_or_generate(path, generator_fn):
    """Load a dataset CSV if present, otherwise generate a fresh sample one."""
    if os.path.exists(path):
        df = pd.read_csv(path)
        print(f"Loaded existing dataset: {path} ({len(df)} rows)")
    else:
        df = generator_fn()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        df.to_csv(path, index=False)
        print(f"Generated new sample dataset: {path} ({len(df)} rows)")
    return df


def clean_dataframe(df, required_cols):
    """Basic cleaning: drop missing values, keep only sane rows (numeric cols only)."""
    df = df.dropna(subset=required_cols).copy()
    for col in required_cols:
        if pd.api.types.is_numeric_dtype(df[col]):
            df = df[np.isfinite(df[col])]
    return df


def train_regression_model():
    print("\n=== Training Regression Model (Expense Prediction) ===")
    df = load_or_generate(Config.EXPENSE_DATASET_PATH, generate_expense_dataset)
    df = clean_dataframe(df, REGRESSION_FEATURES + [REGRESSION_TARGET])

    X = df[REGRESSION_FEATURES]
    y = df[REGRESSION_TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    rf_model = RandomForestRegressor(
        n_estimators=200, max_depth=10, random_state=42, n_jobs=-1
    )
    rf_model.fit(X_train, y_train)
    rf_pred = rf_model.predict(X_test)

    # Baseline linear regression for comparison
    lr_model = LinearRegression()
    lr_model.fit(X_train, y_train)
    lr_pred = lr_model.predict(X_test)

    def regression_metrics(y_true, y_pred):
        mae = mean_absolute_error(y_true, y_pred)
        mse = mean_squared_error(y_true, y_pred)
        rmse = np.sqrt(mse)
        r2 = r2_score(y_true, y_pred)
        return {"MAE": round(mae, 2), "MSE": round(mse, 2),
                "RMSE": round(rmse, 2), "R2_Score": round(r2, 4)}

    rf_metrics = regression_metrics(y_test, rf_pred)
    lr_metrics = regression_metrics(y_test, lr_pred)

    print("Random Forest Regressor:", rf_metrics)
    print("Linear Regression (baseline):", lr_metrics)

    # Choose the better model based on R2 (prefer RF, per project brief)
    chosen_model, chosen_name, chosen_metrics = rf_model, "RandomForestRegressor", rf_metrics

    importances = chosen_model.feature_importances_
    importances = importances / importances.sum()  # normalize to sum to 1
    feature_importance = {
        feat: round(float(imp) * 100, 2)
        for feat, imp in sorted(
            zip(REGRESSION_FEATURES, importances), key=lambda x: x[1], reverse=True
        )
    }

    os.makedirs(Config.MODELS_DIR, exist_ok=True)
    joblib.dump(chosen_model, Config.REGRESSOR_PATH)

    meta = {
        "model_name": chosen_name,
        "features": REGRESSION_FEATURES,
        "target": REGRESSION_TARGET,
        "feature_importance": feature_importance,
        "metrics": {
            "RandomForestRegressor": rf_metrics,
            "LinearRegression": lr_metrics,
        },
        "chosen_model_metrics": chosen_metrics,
        "n_train": len(X_train),
        "n_test": len(X_test),
    }
    with open(Config.REGRESSOR_META_PATH, "w") as f:
        json.dump(meta, f, indent=2)

    print(f"Saved regression model -> {Config.REGRESSOR_PATH}")
    return meta


def train_classification_model():
    print("\n=== Training Classification Model (Financial Health) ===")
    df = load_or_generate(Config.FINANCIAL_HEALTH_DATASET_PATH, generate_financial_health_dataset)
    df = clean_dataframe(df, CLASSIFICATION_FEATURES + [CLASSIFICATION_TARGET])

    X = df[CLASSIFICATION_FEATURES]
    y = df[CLASSIFICATION_TARGET]
    labels = sorted(y.unique().tolist())

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    rf_model = RandomForestClassifier(
        n_estimators=200, max_depth=8, random_state=42, n_jobs=-1
    )
    rf_model.fit(X_train, y_train)
    rf_pred = rf_model.predict(X_test)

    # Comparison model: Logistic Regression (needs scaling)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    lr_model = LogisticRegression(max_iter=1000)
    lr_model.fit(X_train_scaled, y_train)
    lr_pred = lr_model.predict(X_test_scaled)

    def classification_metrics(y_true, y_pred):
        return {
            "Accuracy": round(accuracy_score(y_true, y_pred), 4),
            "Precision": round(precision_score(y_true, y_pred, average="macro", zero_division=0), 4),
            "Recall": round(recall_score(y_true, y_pred, average="macro", zero_division=0), 4),
            "F1_Score": round(f1_score(y_true, y_pred, average="macro", zero_division=0), 4),
        }

    rf_metrics = classification_metrics(y_test, rf_pred)
    lr_metrics = classification_metrics(y_test, lr_pred)
    cm = confusion_matrix(y_test, rf_pred, labels=labels).tolist()

    print("Random Forest Classifier:", rf_metrics)
    print("Logistic Regression (comparison):", lr_metrics)
    print("Confusion Matrix (RF), labels =", labels)
    print(np.array(cm))

    chosen_model, chosen_name, chosen_metrics = rf_model, "RandomForestClassifier", rf_metrics

    importances = chosen_model.feature_importances_
    importances = importances / importances.sum()
    feature_importance = {
        feat: round(float(imp) * 100, 2)
        for feat, imp in sorted(
            zip(CLASSIFICATION_FEATURES, importances), key=lambda x: x[1], reverse=True
        )
    }

    os.makedirs(Config.MODELS_DIR, exist_ok=True)
    joblib.dump(chosen_model, Config.CLASSIFIER_PATH)

    meta = {
        "model_name": chosen_name,
        "features": CLASSIFICATION_FEATURES,
        "target": CLASSIFICATION_TARGET,
        "class_labels": chosen_model.classes_.tolist(),
        "feature_importance": feature_importance,
        "metrics": {
            "RandomForestClassifier": rf_metrics,
            "LogisticRegression": lr_metrics,
        },
        "chosen_model_metrics": chosen_metrics,
        "confusion_matrix": {"labels": labels, "matrix": cm},
        "n_train": len(X_train),
        "n_test": len(X_test),
    }
    with open(Config.CLASSIFIER_META_PATH, "w") as f:
        json.dump(meta, f, indent=2)

    print(f"Saved classification model -> {Config.CLASSIFIER_PATH}")
    return meta


if __name__ == "__main__":
    reg_meta = train_regression_model()
    clf_meta = train_classification_model()
    print("\nAll models trained and saved successfully.")
    print("NOTE: dataset used is a synthetic project/demo dataset, not real validated financial data.")
