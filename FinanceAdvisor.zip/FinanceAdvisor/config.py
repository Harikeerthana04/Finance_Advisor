import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    """Central application configuration."""
    SECRET_KEY = os.environ.get("SECRET_KEY", "finance-advisor-dev-secret-key")
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'database', 'finance.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # ML model paths
    MODELS_DIR = os.path.join(BASE_DIR, "models")
    REGRESSOR_PATH = os.path.join(MODELS_DIR, "expense_regressor.pkl")
    CLASSIFIER_PATH = os.path.join(MODELS_DIR, "financial_classifier.pkl")
    REGRESSOR_META_PATH = os.path.join(MODELS_DIR, "expense_regressor_meta.json")
    CLASSIFIER_META_PATH = os.path.join(MODELS_DIR, "financial_classifier_meta.json")

    # Dataset paths
    DATASET_DIR = os.path.join(BASE_DIR, "dataset")
    EXPENSE_DATASET_PATH = os.path.join(DATASET_DIR, "expense_data.csv")
    FINANCIAL_HEALTH_DATASET_PATH = os.path.join(DATASET_DIR, "financial_health_data.csv")
