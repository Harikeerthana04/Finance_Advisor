# Finance Advisor

**Plan Today, Prosper Tomorrow**

A full-stack ML web application for personal finance planning, built for a
medium-level BTech Machine Learning project. Core ML components:

1. **Regression** — Next-month expense prediction (Random Forest Regressor, with Linear Regression as a compared baseline)
2. **Classification** — Financial health classification: Healthy / Moderate / Risky (Random Forest Classifier, with Logistic Regression as a compared baseline)

No GenAI, LLMs, RAG, NLP, or chatbots are used anywhere in this project —
predictions come from trained scikit-learn models, and recommendations are
generated with plain Python rules.

---

## 1. Tech Stack

- **Frontend:** HTML5, CSS3, JavaScript, Bootstrap 5, Chart.js
- **Backend:** Python, Flask
- **ML:** pandas, NumPy, scikit-learn, Joblib
- **Database:** SQLite + SQLAlchemy (Flask-SQLAlchemy)

---

## 2. Project Structure

```text
FinanceAdvisor/
│
├── app.py                     # Flask application & routes
├── config.py                  # App configuration (paths, DB URI)
├── models.py                  # SQLAlchemy ORM models
├── ml_service.py              # Loads trained models, runs predictions
├── generate_dataset.py        # Generates the synthetic demo dataset
├── train_models.py            # Trains + evaluates + saves both ML models
├── requirements.txt
│
├── database/
│   └── finance.db             # Created automatically on first run
│
├── models/                    # Trained model files (created by train_models.py)
│   ├── expense_regressor.pkl
│   ├── expense_regressor_meta.json
│   ├── financial_classifier.pkl
│   └── financial_classifier_meta.json
│
├── dataset/                   # Sample/demo datasets (created automatically if missing)
│   ├── expense_data.csv
│   └── financial_health_data.csv
│
├── templates/                 # Jinja2 HTML templates
├── static/
│   ├── css/style.css
│   └── js/script.js
│
└── README.md
```

---

## 3. Installation

```bash
# 1. Create and activate a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
```

---

## 4. Train the ML Models (required before first run)

```bash
python train_models.py
```

This will:
1. Generate a synthetic sample/demo dataset (`dataset/expense_data.csv` and
   `dataset/financial_health_data.csv`) if they don't already exist.
2. Clean the data and split it into train/test sets.
3. Train the Random Forest Regressor (and a Linear Regression baseline).
4. Train the Random Forest Classifier (and a Logistic Regression baseline).
5. Compute real evaluation metrics (MAE, MSE, RMSE, R² for regression;
   Accuracy, Precision, Recall, F1, Confusion Matrix for classification).
6. Save both models to `models/*.pkl`, and their metadata (feature
   importances + metrics) to `models/*_meta.json`.

You should see console output similar to:

```
=== Training Regression Model (Expense Prediction) ===
Random Forest Regressor: {'MAE': ..., 'MSE': ..., 'RMSE': ..., 'R2_Score': ...}
...
=== Training Classification Model (Financial Health) ===
Random Forest Classifier: {'Accuracy': ..., 'Precision': ..., 'Recall': ..., 'F1_Score': ...}
...
All models trained and saved successfully.
```

> **Note:** The dataset is a synthetic **project/demo dataset** built from
> reasonable financial rules-of-thumb plus randomness. It is not real
> financial survey data and carries no certification. If you have a real,
> validated dataset, replace the CSVs in `dataset/` (keeping the same column
> names) and re-run `train_models.py`.

---

## 5. Run the Application

```bash
python app.py
```

Then open your browser at:

```
http://127.0.0.1:5000
```

The app seeds a demo user ("Keerthana") with sample financial data on first
run, matching the reference UI. This is a single-user demo project — the
login page is simplified and does not enforce real authentication.

---

## 6. Using the App

| Page | What it does |
|---|---|
| **Dashboard** | Overview: income/expense/savings/status summary cards, expense breakdown doughnut chart, quick insights, expense trend, quick-action links |
| **Expense Prediction** | Enter this month's income & category spending → Random Forest **regression** model predicts next month's total expense, shows current vs. predicted comparison, real model-derived feature importance, and a 6-month trend chart |
| **Financial Status** | Enter income/expenses/savings/debt → Random Forest **classification** model predicts Healthy / Moderate / Risky, with real `predict_proba()` confidence scores and rule-based recommendations |
| **Goal Planner** | Enter a savings goal & timeframe → plain arithmetic (`goal ÷ months`) calculates required monthly saving and achievability — **not** an ML prediction |
| **History** | All past predictions/analyses/goal calculations, stored in SQLite, filterable by type, with a "View" detail modal |
| **Profile** | Update personal info and preferences, stored in SQLite |

---

## 7. Model Evaluation (example results from this build)

Exact numbers will vary slightly each time you regenerate the dataset/retrain
(random splits), but a representative run produced:

**Regression (Expense Prediction):**
| Model | MAE | RMSE | R² |
|---|---|---|---|
| Random Forest Regressor (used in-app) | ~1,900 | ~2,360 | ~0.88 |
| Linear Regression (baseline) | ~1,300 | ~1,660 | ~0.94 |

**Classification (Financial Health):**
| Model | Accuracy | Precision | Recall | F1 |
|---|---|---|---|---|
| Random Forest Classifier (used in-app) | ~0.82 | ~0.75 | ~0.74 | ~0.74 |
| Logistic Regression (comparison) | ~0.85+ | ~0.79+ | ~0.77+ | ~0.78+ |

These numbers are computed from an actual held-out test split — not
fabricated — and are re-generated every time you run `train_models.py`. On
this particular synthetic dataset, Linear/Logistic baselines sometimes edge
out the Random Forest models slightly, because the underlying synthetic
relationships are fairly linear — the app still uses the Random Forest
models by default per the project brief, and reports both honestly in
`models/*_meta.json`.

---

## 8. Re-training with Your Own Data

Replace the CSV files in `dataset/` with your own data, keeping these exact
column names:

**`expense_data.csv`** (regression):
`income, food_expense, shopping_expense, transport_expense, bills, entertainment, other_expense, previous_total_expense, next_month_expense`

**`financial_health_data.csv`** (classification):
`income, total_expense, savings, debt, savings_percentage, financial_status`
(`financial_status` must be one of: `Healthy`, `Moderate`, `Risky`)

Then re-run:

```bash
python train_models.py
```

and restart the Flask app so it picks up the newly trained models.

---

## 9. Troubleshooting

- **"Prediction model is not available" error in the UI:** run
  `python train_models.py` before starting the Flask app.
- **Database errors on first run:** delete `database/finance.db` and restart
  `app.py` — it will recreate the schema and reseed the demo user.
- **Port already in use:** change the port in the last line of `app.py`
  (`app.run(debug=True, port=5000)`).

---

## 10. Disclaimer

This is an academic/demo project. The included dataset is synthetic and the
models are for educational purposes only — nothing in this app constitutes
certified financial, medical, or scientific advice.
