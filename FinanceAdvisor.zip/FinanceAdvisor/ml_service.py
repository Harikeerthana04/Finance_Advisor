"""
ml_service.py
-------------
Loads the trained ML models (once, at app startup) and exposes clean
helper functions the Flask routes call to get real predictions -
no hard-coded ML outputs anywhere in this file.
"""
import os
import json
import joblib
import numpy as np
import pandas as pd

from config import Config

_regressor = None
_classifier = None
_regressor_meta = None
_classifier_meta = None


class ModelNotTrainedError(Exception):
    """Raised when a required model file is missing."""
    pass


def _load_json(path):
    if not os.path.exists(path):
        return {}
    with open(path, "r") as f:
        return json.load(f)


def load_models():
    """Load models + metadata into memory. Safe to call multiple times."""
    global _regressor, _classifier, _regressor_meta, _classifier_meta

    if not os.path.exists(Config.REGRESSOR_PATH):
        raise ModelNotTrainedError(
            "Expense regressor model not found. Run `python train_models.py` first."
        )
    if not os.path.exists(Config.CLASSIFIER_PATH):
        raise ModelNotTrainedError(
            "Financial health classifier model not found. Run `python train_models.py` first."
        )

    _regressor = joblib.load(Config.REGRESSOR_PATH)
    _classifier = joblib.load(Config.CLASSIFIER_PATH)
    _regressor_meta = _load_json(Config.REGRESSOR_META_PATH)
    _classifier_meta = _load_json(Config.CLASSIFIER_META_PATH)
    return True


def models_ready():
    return _regressor is not None and _classifier is not None


def predict_next_month_expense(income, food, shopping, transport, bills,
                                entertainment, other, previous_total_expense=None):
    """
    Regression: predicts next month's total expense using the trained
    RandomForestRegressor. Returns predicted value + feature importance.
    """
    if _regressor is None:
        raise ModelNotTrainedError("Regression model is not loaded.")

    current_total = food + shopping + transport + bills + entertainment + other
    if previous_total_expense is None:
        previous_total_expense = current_total

    features = _regressor_meta.get("features", [
        "income", "food_expense", "shopping_expense", "transport_expense",
        "bills", "entertainment", "other_expense", "previous_total_expense",
    ])

    row = {
        "income": income,
        "food_expense": food,
        "shopping_expense": shopping,
        "transport_expense": transport,
        "bills": bills,
        "entertainment": entertainment,
        "other_expense": other,
        "previous_total_expense": previous_total_expense,
    }
    X = pd.DataFrame([[row[f] for f in features]], columns=features)
    prediction = float(_regressor.predict(X)[0])
    prediction = max(prediction, 0.0)

    difference = prediction - current_total
    pct_change = (difference / current_total * 100) if current_total > 0 else 0.0

    return {
        "current_expense": round(current_total, 2),
        "predicted_expense": round(prediction, 2),
        "difference": round(difference, 2),
        "percentage_change": round(pct_change, 2),
        "feature_importance": _regressor_meta.get("feature_importance", {}),
        "model_used": _regressor_meta.get("model_name", "RandomForestRegressor"),
        "model_metrics": _regressor_meta.get("chosen_model_metrics", {}),
    }


def predict_financial_status(income, total_expense, savings, debt, savings_percentage=None):
    """
    Classification: predicts Healthy / Moderate / Risky financial status
    using the trained classifier, with real predict_proba() probabilities.
    """
    if _classifier is None:
        raise ModelNotTrainedError("Classification model is not loaded.")

    if savings_percentage is None:
        savings_percentage = (savings / income * 100) if income > 0 else 0.0

    features = _classifier_meta.get("features", [
        "income", "total_expense", "savings", "debt", "savings_percentage",
    ])
    row = {
        "income": income,
        "total_expense": total_expense,
        "savings": savings,
        "debt": debt,
        "savings_percentage": savings_percentage,
    }
    X = pd.DataFrame([[row[f] for f in features]], columns=features)

    prediction = _classifier.predict(X)[0]

    probabilities = {}
    if hasattr(_classifier, "predict_proba"):
        proba = _classifier.predict_proba(X)[0]
        classes = _classifier.classes_
        probabilities = {
            cls: round(float(p) * 100, 2) for cls, p in zip(classes, proba)
        }

    recommendations = _generate_recommendations(
        income, total_expense, savings, debt, savings_percentage, prediction
    )

    return {
        "status": str(prediction),
        "probabilities": probabilities,
        "feature_importance": _classifier_meta.get("feature_importance", {}),
        "model_used": _classifier_meta.get("model_name", "RandomForestClassifier"),
        "model_metrics": _classifier_meta.get("chosen_model_metrics", {}),
        "recommendations": recommendations,
    }


def _generate_recommendations(income, total_expense, savings, debt, savings_percentage, status):
    """
    Plain Python rule-based recommendations (NOT an LLM/GenAI) derived
    from the user's actual entered values and the predicted status.
    """
    recs = []
    expense_ratio = (total_expense / income * 100) if income > 0 else 0
    debt_to_income = (debt / income * 100) if income > 0 else 0

    if expense_ratio > 70:
        recs.append("Try to reduce non-essential expenses; your expenses are a large share of your income.")
    else:
        recs.append("Keep tracking your spending regularly to stay on top of your budget.")

    if savings_percentage < 15:
        recs.append("Increase your monthly savings — aim for at least 15-20% of your income.")
    elif savings_percentage >= 30:
        recs.append("Great savings rate — consider directing part of it toward long-term investments.")
    else:
        recs.append("Your savings rate is reasonable; try to grow it gradually each month.")

    if debt_to_income > 30:
        recs.append("Your debt is high relative to income — prioritize paying it down before new spending.")
    elif debt > 0:
        recs.append("Avoid taking on unnecessary new debt while you pay down existing balances.")

    if status == "Risky":
        recs.append("Consider building a small emergency fund before making discretionary purchases.")
    elif status == "Healthy":
        recs.append("You're in a strong position — keep up your current financial habits.")

    return recs[:5]


def get_regressor_metadata():
    return _regressor_meta or {}


def get_classifier_metadata():
    return _classifier_meta or {}
