"""
generate_dataset.py
--------------------
Generates realistic SAMPLE/DEMO datasets for the Finance Advisor project.

This is a project/demo dataset built from reasonable financial rules-of-thumb
plus random noise - it is NOT real financial survey data and is not
certified in any way. It exists so the regression and classification
models have something realistic to train on when a real dataset isn't
supplied.

Run:  python generate_dataset.py
"""
import numpy as np
import pandas as pd
import os

np.random.seed(42)
OUT_DIR = os.path.join(os.path.dirname(__file__), "dataset")
os.makedirs(OUT_DIR, exist_ok=True)

N = 1500  # number of synthetic records


def generate_expense_dataset(n=N):
    """Regression dataset: predict next_month_expense from spending pattern."""
    income = np.random.normal(45000, 15000, n).clip(12000, 150000)

    # Spending categories have a mild income-scaling component plus a large
    # independent random component, so categories carry their own signal
    # rather than being fully explained by income alone.
    food = income * 0.10 + np.random.normal(3500, 1800, n)
    shopping = income * 0.06 + np.random.normal(3000, 2200, n)
    transport = income * 0.04 + np.random.normal(1800, 1100, n)
    bills = income * 0.10 + np.random.normal(3200, 1500, n)
    entertainment = income * 0.05 + np.random.normal(2200, 1700, n)
    other = income * 0.04 + np.random.normal(1800, 1100, n)

    food = food.clip(500, None)
    shopping = shopping.clip(300, None)
    transport = transport.clip(300, None)
    bills = bills.clip(500, None)
    entertainment = entertainment.clip(200, None)
    other = other.clip(200, None)

    # previous_total_expense represents LAST month's actual total (not simply
    # the sum of this month's categories) -- it correlates with income and
    # this month's categories but is its own independent signal, the way a
    # real "last month's bill" would be.
    category_sum = food + shopping + transport + bills + entertainment + other
    previous_total_expense = (
        category_sum * 0.35 + income * 0.08 + np.random.normal(0, 3500, n)
    )
    previous_total_expense = previous_total_expense.clip(2000, None)

    # Next month expense should stay close to this month's actual total
    # spending (realistic month-to-month behaviour), with a small growth
    # drift, mild persistence from last month's total, and category-level
    # volatility (shopping/entertainment swing more than fixed costs like
    # bills) so that no single feature fully dominates model importance.
    growth = np.random.normal(1.03, 0.04, n)  # ~3% average monthly growth
    category_sum = food + shopping + transport + bills + entertainment + other

    next_month_expense = (
        category_sum * 0.80 * growth
        + previous_total_expense * 0.15
        + income * 0.015
        + shopping * 0.08          # extra volatility on top of base share
        + entertainment * 0.06
    )
    seasonal_noise = np.random.normal(0, category_sum * 0.04, n)
    next_month_expense = (next_month_expense + seasonal_noise).clip(1500, None)

    df = pd.DataFrame({
        "income": income.round(2),
        "food_expense": food.round(2),
        "shopping_expense": shopping.round(2),
        "transport_expense": transport.round(2),
        "bills": bills.round(2),
        "entertainment": entertainment.round(2),
        "other_expense": other.round(2),
        "previous_total_expense": previous_total_expense.round(2),
        "next_month_expense": next_month_expense.round(2),
    })
    return df


def generate_financial_health_dataset(n=N):
    """Classification dataset: Healthy / Moderate / Risky financial status."""
    income = np.random.normal(45000, 16000, n).clip(10000, 160000)
    expense_ratio = np.random.uniform(0.35, 1.15, n)  # expenses as a fraction of income
    total_expense = income * expense_ratio

    savings = (income - total_expense) + np.random.normal(0, 1500, n)
    savings = savings.clip(-20000, None)

    debt = np.random.exponential(scale=income * 0.15, size=n)
    debt = debt.clip(0, income * 2.5)

    savings_percentage = np.clip((savings / income) * 100, -100, 100)

    debt_to_income = debt / income

    # Rule-based scoring used ONLY to construct plausible ground-truth labels
    # for a synthetic training set (the actual app classifies using the
    # trained ML model, not these rules).
    score = (
        (savings_percentage / 100) * 2.2
        - debt_to_income * 1.6
        - (expense_ratio - 0.6) * 1.8
    )
    score += np.random.normal(0, 0.35, n)  # label noise

    financial_status = np.where(
        score > 0.55, "Healthy",
        np.where(score > -0.05, "Moderate", "Risky")
    )

    df = pd.DataFrame({
        "income": income.round(2),
        "total_expense": total_expense.round(2),
        "savings": savings.round(2),
        "debt": debt.round(2),
        "savings_percentage": savings_percentage.round(2),
        "financial_status": financial_status,
    })
    return df


if __name__ == "__main__":
    expense_df = generate_expense_dataset()
    health_df = generate_financial_health_dataset()

    expense_path = os.path.join(OUT_DIR, "expense_data.csv")
    health_path = os.path.join(OUT_DIR, "financial_health_data.csv")

    expense_df.to_csv(expense_path, index=False)
    health_df.to_csv(health_path, index=False)

    print(f"Saved {len(expense_df)} rows -> {expense_path}")
    print(f"Saved {len(health_df)} rows -> {health_path}")
    print("\nFinancial status label distribution:")
    print(health_df["financial_status"].value_counts())
