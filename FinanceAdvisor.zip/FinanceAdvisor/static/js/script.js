document.addEventListener("DOMContentLoaded", function () {

    // ============================================================
    // RESPONSIVE SIDEBAR
    // ============================================================

    const hamburger = document.getElementById("faHamburger");
    const sidebar = document.getElementById("faSidebar");

    if (hamburger && sidebar) {

        hamburger.addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();

            sidebar.classList.toggle("open");
        });

        // Close sidebar when a navigation link is clicked
        const sidebarLinks = sidebar.querySelectorAll("a");

        sidebarLinks.forEach(function (link) {
            link.addEventListener("click", function () {
                sidebar.classList.remove("open");
            });
        });

        // Close sidebar when clicking outside it on small screens
        document.addEventListener("click", function (event) {
            if (window.innerWidth <= 900) {

                const clickedInsideSidebar = sidebar.contains(event.target);
                const clickedHamburger = hamburger.contains(event.target);

                if (!clickedInsideSidebar && !clickedHamburger) {
                    sidebar.classList.remove("open");
                }
            }
        });
    }


    // ============================================================
    // FLASH MESSAGE
    // ============================================================

    const flashToast = document.getElementById("flashToast");

    if (flashToast) {
        setTimeout(() => {
            flashToast.style.display = "none";
        }, 4000);
    }

});

/**
 * Shows a small toast notification (success/error) in the top-right corner.
 */
function faShowToast(message, type = "success") {
  const toast = document.getElementById("faApiToast");
  if (!toast) return;
  toast.textContent = message;
  toast.className = `fa-toast ${type}`;
  toast.style.display = "block";
  setTimeout(() => { toast.style.display = "none"; }, 4000);
}

/**
 * Wraps fetch() with JSON body/response handling and basic error surfacing.
 */
async function faPostJSON(url, payload) {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    let data;
    try {
      data = await response.json();
    } catch (parseErr) {
      throw new Error(`Server returned an unexpected response (status ${response.status}). Check the terminal running app.py for errors.`);
    }

    if (!response.ok) {
      throw new Error(data.error || `Request failed (status ${response.status}).`);
    }
    return data;
  } catch (err) {
    console.error(`faPostJSON error calling ${url}:`, err);
    faShowToast(err.message || "Network error. Please try again.", "danger");
    throw err;
  }
}

/**
 * Toggles a button into a loading state with a spinner.
 */
function faSetButtonLoading(button, loading, loadingText = "Processing...") {
  if (!button) return;
  if (loading) {
    button.dataset.originalText = button.innerHTML;
    button.innerHTML = `<span class="fa-spinner"></span> ${loadingText}`;
    button.disabled = true;
  } else {
    button.innerHTML = button.dataset.originalText || button.innerHTML;
    button.disabled = false;
  }
}

function faFormatCurrency(value) {
  const num = Number(value) || 0;
  return "₹" + num.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

// ============================================================
// QUICK NAVIGATION SEARCH
// ============================================================

document.addEventListener("DOMContentLoaded", function () {

  const searchInput = document.getElementById("faSearch");

  if (!searchInput) return;

  searchInput.addEventListener("keydown", function (event) {

    // Only search when Enter is pressed
    if (event.key !== "Enter") return;

    const search = searchInput.value.trim().toLowerCase();

    if (!search) return;

    // Navigation keywords
    const pages = [
      {
        keywords: ["dashboard", "home", "main"],
        url: "/dashboard"
      },
      {
        keywords: [
          "expense",
          "expenses",
          "expense prediction",
          "predict expense"
        ],
        url: "/expense-prediction"
      },
      {
        keywords: [
          "financial status",
          "financial",
          "status",
          "financial health"
        ],
        url: "/financial-status"
      },
      {
        keywords: [
          "goal",
          "goals",
          "goal planner",
          "saving goal"
        ],
        url: "/goal-planner"
      },
      {
        keywords: [
          "history",
          "prediction history",
          "records"
        ],
        url: "/history"
      },
      {
        keywords: [
          "profile",
          "account",
          "settings"
        ],
        url: "/profile"
      }
    ];

    // Find matching page
    const matchedPage = pages.find(page =>
      page.keywords.some(keyword =>
        keyword.includes(search) || search.includes(keyword)
      )
    );

    if (matchedPage) {

      window.location.href = matchedPage.url;

    } else {

      faShowToast(
        "No matching page found. Try Dashboard, Expense, Financial Status, Goal, History, or Profile.",
        "danger"
      );

    }

  });

});

// ============================================================
// NOTIFICATIONS
// ============================================================

document.addEventListener("DOMContentLoaded", function () {

    const notificationBell =
        document.getElementById("faNotificationBell");

    const notificationList =
        document.getElementById("faNotificationList");

    const notificationDot =
        document.getElementById("faNotificationDot");

    const notificationClear =
        document.getElementById("faNotificationClear");


    if (!notificationBell || !notificationList) {
        return;
    }


    // ----------------------------------------------------------
    // LOAD NOTIFICATIONS
    // ----------------------------------------------------------

    async function loadNotifications() {

        try {

            const response = await fetch("/api/notifications");

            if (!response.ok) {
                throw new Error("Unable to load notifications.");
            }

            const data = await response.json();

            const notifications = data.notifications || [];


            // --------------------------------------------------
            // NO NOTIFICATIONS
            // --------------------------------------------------

            if (notifications.length === 0) {

                notificationList.innerHTML = `
                    <div class="fa-notification-empty">

                        <div class="fa-notification-icon">
                            🔔
                        </div>

                        <p>
                            No new notifications
                        </p>

                        <small>
                            You're all caught up!
                        </small>

                    </div>
                `;

                if (notificationDot) {
                    notificationDot.style.display = "none";
                }

                return;
            }


            // --------------------------------------------------
            // SHOW RED DOT
            // --------------------------------------------------

            if (notificationDot) {
                notificationDot.style.display = "block";
            }


            // --------------------------------------------------
            // DISPLAY NOTIFICATIONS
            // --------------------------------------------------

            notificationList.innerHTML = notifications.map(
                function (notification) {

                    return `
                        <div class="fa-notification-item ${notification.type || "info"}">

                            <div class="fa-notification-item-icon">
                                ${notification.icon || "🔔"}
                            </div>

                            <div class="fa-notification-item-content">

                                <div class="fa-notification-item-title">
                                    ${notification.title}
                                </div>

                                <div class="fa-notification-item-message">
                                    ${notification.message}
                                </div>

                            </div>

                        </div>
                    `;

                }
            ).join("");


        } catch (error) {

            console.error(
                "Notification loading error:",
                error
            );

            notificationList.innerHTML = `
                <div class="fa-notification-error">
                    Unable to load notifications.
                </div>
            `;

        }

    }


    // Load notifications when page opens
    loadNotifications();


    // Refresh notifications when bell is clicked
    notificationBell.addEventListener(
        "click",
        function () {
            loadNotifications();
        }
    );


    // ----------------------------------------------------------
    // CLEAR NOTIFICATIONS FROM CURRENT DISPLAY
    // ----------------------------------------------------------

    if (notificationClear) {

        notificationClear.addEventListener(
            "click",
            function (event) {

                event.preventDefault();
                event.stopPropagation();

                notificationList.innerHTML = `
                    <div class="fa-notification-empty">

                        <div class="fa-notification-icon">
                            🔔
                        </div>

                        <p>
                            No new notifications
                        </p>

                        <small>
                            You're all caught up!
                        </small>

                    </div>
                `;

                if (notificationDot) {
                    notificationDot.style.display = "none";
                }

            }
        );

    }

});