"""
app.py
------
Finance Advisor - main Flask application.

Run with:  python app.py
(Make sure you've run `python train_models.py` at least once first.)
"""
import email
import os
import json

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

from config import Config
from models import db, User, FinancialRecord, PredictionHistory, Goal
import ml_service


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)

    with app.app_context():
        db.create_all()
        try:
            ml_service.load_models()
        except ml_service.ModelNotTrainedError as e:
            app.logger.warning(str(e))

    register_routes(app)
    return app


def seed_demo_user():
    """Create a demo user (Keerthana) on first run, matching the reference UI."""
    user = User.query.filter_by(email="keerthana@example.com").first()
    if user:
        return user

    user = User(
        name="Keerthana",
        email="keerthana@example.com",
        college="Malla Reddy Engineering College for Women",
        location="India",
        monthly_income=40000,
        currency="INR (₹)",
        theme="Light",
        expense_reminder=True,
        goal_notifications=True,
        email_updates=False,
    )
    db.session.add(user)
    db.session.commit()

    record = FinancialRecord(
        user_id=user.id,
        income=40000,
        food_expense=6000,
        shopping_expense=5000,
        transport_expense=3000,
        bills=6000,
        entertainment=4000,
        other_expense=4000,
        total_expense=28000,
        savings=12000,
        debt=5000,
    )
    db.session.add(record)
    db.session.commit()
    return user


def current_user():
    """Return the currently logged-in user."""
    user_id = session.get("user_id")

    if not user_id:
        return None

    return db.session.get(User, user_id)


def login_required(view):
    """Protect pages that require authentication."""
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))

        user = current_user()

        if not user:
            session.clear()
            return redirect(url_for("login"))

        return view(*args, **kwargs)

    return wrapped_view


def latest_financial_record(user_id):
    return (
        FinancialRecord.query.filter_by(user_id=user_id)
        .order_by(FinancialRecord.date.desc())
        .first()
    )


def register_routes(app):

    # ---------- Static/simple page routes ----------

    @app.route("/")
    def index():
        if "user_id" in session:
            return redirect(url_for("dashboard"))
        return redirect(url_for("login"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")

            user = User.query.filter_by(email=email).first()

            if user and user.password_hash:
                try:
                    if check_password_hash(user.password_hash, password):

                        session.clear()

                        session["user_id"] = user.id
                        session["logged_in"] = True

                        flash("Login successful!", "success")

                        return redirect(url_for("dashboard"))

                except Exception:
                    pass

            flash("Invalid email or password.", "danger")

        return render_template("login.html")

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            confirm_password = request.form.get("confirm_password", "")

            # Validation
            if not name:
                flash("Please enter your name.", "danger")
                return render_template("register.html")

            if not email:
                flash("Please enter your email.", "danger")
                return render_template("register.html")

            if len(password) < 6:
                flash(
                    "Password must contain at least 6 characters.",
                    "danger"
                )
                return render_template("register.html")

            if password != confirm_password:
                flash(
                    "Passwords do not match.",
                    "danger"
                )
                return render_template("register.html")

            # Check whether account already exists
            existing_user = User.query.filter_by(
                email=email
            ).first()

            if existing_user:
                flash(
                    "An account with this email already exists. Please login.",
                    "danger"
                )
                return render_template("register.html")

            # Create new user
            user = User(
                name=name,
                email=email,
                password_hash=generate_password_hash(password),
                college="",
                location="India",
                monthly_income=0,
                currency="INR (₹)",
                theme="Dark",
                expense_reminder=True,
                goal_notifications=True,
                email_updates=False,
            )

            db.session.add(user)
            db.session.commit()

            # Create initial financial record
            record = FinancialRecord(
                user_id=user.id,
                income=0,
                food_expense=0,
                shopping_expense=0,
                transport_expense=0,
                bills=0,
                entertainment=0,
                other_expense=0,
                total_expense=0,
                savings=0,
                debt=0,
            )

            db.session.add(record)
            db.session.commit()

            flash(
                "Account created successfully! Please login.",
                "success"
            )
            return redirect(url_for("login"))

        return render_template("register.html")

    @app.route("/logout")
    def logout():
        session.clear()
        flash(
            "You have been logged out successfully.",
            "success"
        )
        return redirect(url_for("login"))

    @app.route("/dashboard")
    @login_required
    def dashboard():
        user = current_user()
        record = latest_financial_record(user.id)

        if record:
            income = record.income
            total_expense = record.total_expense
            savings = record.savings
            expense_breakdown = {
                "Food": record.food_expense,
                "Shopping": record.shopping_expense,
                "Transport": record.transport_expense,
                "Bills": record.bills,
                "Entertainment": record.entertainment,
                "Other": record.other_expense,
            }
        else:
            income, total_expense, savings = user.monthly_income, 0, 0
            expense_breakdown = {}

        # Determine financial status quickly for the summary card using the
        # trained classifier (falls back gracefully if models aren't ready).
        status_label = "Unknown"
        if ml_service.models_ready() and income > 0:
            savings_pct = (savings / income * 100) if income else 0
            try:
                result = ml_service.predict_financial_status(
                    income, total_expense, savings, record.debt if record else 0, savings_pct
                )
                status_label = result["status"]
            except Exception:
                status_label = "Unknown"

        insights = build_dashboard_insights(user, record, status_label)

        # Expense trend: pull last 6 predictions/records, else demo data.
        trend = build_expense_trend(user.id)

        return render_template(
            "dashboard.html",
            user=user,
            income=income,
            total_expense=total_expense,
            savings=savings,
            status_label=status_label,
            expense_breakdown=expense_breakdown,
            insights=insights,
            trend=trend,
            active_page="dashboard",
        )

    @app.route("/expense-prediction")
    @login_required
    def expense_prediction_page():
        user = current_user()
        record = latest_financial_record(user.id)
        meta = ml_service.get_regressor_metadata()
        return render_template(
            "expense_prediction.html",
            user=user,
            record=record,
            model_meta=meta,
            active_page="expense-prediction",
        )

    @app.route("/financial-status")
    @login_required
    def financial_status_page():
        user = current_user()
        record = latest_financial_record(user.id)
        meta = ml_service.get_classifier_metadata()
        return render_template(
            "financial_status.html",
            user=user,
            record=record,
            model_meta=meta,
            active_page="financial-status",
        )

    @app.route("/goal-planner")
    @login_required
    def goal_planner_page():
        user = current_user()
        record = latest_financial_record(user.id)
        return render_template(
            "goal_planner.html",
            user=user,
            record=record,
            active_page="goal-planner",
        )

    @app.route("/history")
    @login_required
    def history_page():
        user = current_user()
        filter_type = request.args.get("type", "All")

        query = PredictionHistory.query.filter_by(user_id=user.id)
        if filter_type != "All":
            query = query.filter_by(prediction_type=filter_type)
        records = query.order_by(PredictionHistory.created_at.desc()).all()

        return render_template(
            "history.html",
            user=user,
            records=records,
            filter_type=filter_type,
            active_page="history",
        )

    @app.route("/history/<int:record_id>")
    @login_required
    def history_detail(record_id):
        record = PredictionHistory.query.get_or_404(record_id)
        input_data = json.loads(record.input_data) if record.input_data else {}
        result_data = json.loads(record.result_data) if record.result_data else {}
        return jsonify({
            "type": record.prediction_type,
            "date": record.created_at.strftime("%d %b %Y, %I:%M %p"),
            "input": input_data,
            "result": result_data,
        })

    @app.route("/profile", methods=["GET", "POST"])
    @login_required
    def profile_page():
        user = current_user()

        if request.method == "POST":
            try:
                user.name = request.form.get("name", user.name).strip() or user.name
                user.email = request.form.get("email", user.email).strip() or user.email
                income_val = request.form.get("monthly_income", "").strip()
                if income_val:
                    user.monthly_income = validate_positive_number(income_val, "Monthly Income")
                user.currency = request.form.get("currency", user.currency)

                user.theme = request.form.get("theme", user.theme)
                user.expense_reminder = "expense_reminder" in request.form
                user.goal_notifications = "goal_notifications" in request.form
                user.email_updates = "email_updates" in request.form

                db.session.commit()
                flash("Profile updated successfully.", "success")
            except ValidationError as e:
                flash(str(e), "danger")
            return redirect(url_for("profile_page"))

        return render_template("profile.html", user=user, active_page="profile")

    # ---------- API / POST routes ----------

    @app.route("/predict-expense", methods=["POST"])
    @login_required
    def predict_expense():
        try:
            data = request.get_json(force=True)
            income = validate_positive_number(data.get("income"), "Monthly Income")
            food = validate_non_negative_number(data.get("food"), "Food Expenses")
            shopping = validate_non_negative_number(data.get("shopping"), "Shopping Expenses")
            transport = validate_non_negative_number(data.get("transport"), "Transport Expenses")
            bills = validate_non_negative_number(data.get("bills"), "Bills")
            entertainment = validate_non_negative_number(data.get("entertainment"), "Entertainment Expenses")
            other = validate_non_negative_number(data.get("other"), "Other Expenses")

            if not ml_service.models_ready():
                return jsonify({"error": "Prediction model is not available. Please run train_models.py."}), 503

            result = ml_service.predict_next_month_expense(
                income, food, shopping, transport, bills, entertainment, other
            )

            user = current_user()

            # Persist as a financial record snapshot. This is saved on a
            # best-effort basis: if the DB write fails for any reason, the
            # user still gets their ML prediction result back rather than
            # a generic 500 error with no output at all.
            try:
                record = FinancialRecord(
                    user_id=user.id, income=income, food_expense=food,
                    shopping_expense=shopping, transport_expense=transport,
                    bills=bills, entertainment=entertainment, other_expense=other,
                    total_expense=result["current_expense"],
                    savings=max(income - result["current_expense"], 0),
                    debt=0,
                )
                db.session.add(record)

                history = PredictionHistory(
                    user_id=user.id,
                    prediction_type="Expense Prediction",
                    input_summary=f"Income ₹{int(income):,}",
                    input_data=json.dumps(data),
                    result=f"₹{int(result['predicted_expense']):,}",
                    result_data=json.dumps(result),
                )
                db.session.add(history)
                db.session.commit()
            except Exception:
                db.session.rollback()
                app.logger.exception("Failed to save expense prediction history (prediction itself still succeeded)")

            return jsonify(result)

        except ValidationError as e:
            return jsonify({"error": str(e)}), 400
        except ml_service.ModelNotTrainedError as e:
            return jsonify({"error": str(e)}), 503
        except Exception as e:
            app.logger.exception("predict_expense failed")
            return jsonify({"error": "Something went wrong while predicting expenses."}), 500

    @app.route("/predict-financial-status", methods=["POST"])
    @login_required
    def predict_financial_status_route():
        try:
            data = request.get_json(force=True)
            income = validate_positive_number(data.get("income"), "Monthly Income")
            total_expense = validate_non_negative_number(data.get("total_expense"), "Total Expenses")
            savings = validate_non_negative_number(data.get("savings"), "Total Savings", allow_zero=True)
            debt = validate_non_negative_number(data.get("debt"), "Current Debt", allow_zero=True)
            savings_percentage = data.get("savings_percentage")
            savings_percentage = float(savings_percentage) if savings_percentage not in (None, "") else None

            if not ml_service.models_ready():
                return jsonify({"error": "Classification model is not available. Please run train_models.py."}), 503

            result = ml_service.predict_financial_status(
                income, total_expense, savings, debt, savings_percentage
            )

            user = current_user()
            try:
                history = PredictionHistory(
                    user_id=user.id,
                    prediction_type="Financial Status",
                    input_summary=f"Savings ₹{int(savings):,}",
                    input_data=json.dumps(data),
                    result=result["status"],
                    result_data=json.dumps(result),
                )
                db.session.add(history)
                db.session.commit()
            except Exception:
                db.session.rollback()
                app.logger.exception("Failed to save financial status history (analysis itself still succeeded)")

            return jsonify(result)

        except ValidationError as e:
            return jsonify({"error": str(e)}), 400
        except ml_service.ModelNotTrainedError as e:
            return jsonify({"error": str(e)}), 503
        except Exception:
            app.logger.exception("predict_financial_status failed")
            return jsonify({"error": "Something went wrong while analyzing financial status."}), 500

    @app.route("/calculate-goal", methods=["POST"])
    @login_required
    def calculate_goal():
        try:
            data = request.get_json(force=True)
            income = validate_positive_number(data.get("income"), "Monthly Income")
            expense = validate_non_negative_number(data.get("expense"), "Current Monthly Expense", allow_zero=True)
            current_saving = validate_non_negative_number(data.get("current_saving"), "Current Monthly Saving", allow_zero=True)
            goal_amount = validate_positive_number(data.get("goal_amount"), "Goal Amount")
            duration = data.get("duration")

            try:
                duration = int(duration)
            except (TypeError, ValueError):
                raise ValidationError("Target Duration must be a whole number of months.")
            if duration <= 0:
                raise ValidationError("Target Duration must be greater than zero.")

            required_monthly_saving = goal_amount / duration  # normal math, not ML
            difference = required_monthly_saving - current_saving
            achievable = current_saving >= required_monthly_saving

            projection = []
            cumulative = 0
            for month in range(1, duration + 1):
                cumulative += current_saving
                projection.append({"month": f"Month {month}", "amount": round(cumulative, 2)})

            if achievable:
                message = (
                    f"Your goal is achievable in {duration} months if your income and "
                    f"spending remain similar."
                )
            else:
                shortfall = round(difference, 2)
                message = (
                    f"At your current saving rate, you'd fall short by ₹{shortfall:,.0f} per "
                    f"month. Increase savings or extend your timeline to reach this goal."
                )

            result = {
                "required_monthly_saving": round(required_monthly_saving, 2),
                "current_monthly_saving": round(current_saving, 2),
                "difference": round(difference, 2),
                "achievable": achievable,
                "message": message,
                "projection": projection,
            }

            user = current_user()
            try:
                goal = Goal(
                    user_id=user.id,
                    goal_amount=goal_amount,
                    target_months=duration,
                    required_monthly_saving=required_monthly_saving,
                    current_monthly_saving=current_saving,
                    status="Achievable" if achievable else "Not Achievable",
                )
                db.session.add(goal)

                history = PredictionHistory(
                    user_id=user.id,
                    prediction_type="Goal Planner",
                    input_summary=f"Goal ₹{int(goal_amount):,}",
                    input_data=json.dumps(data),
                    result="Achievable" if achievable else "Not Achievable",
                    result_data=json.dumps(result),
                )
                db.session.add(history)
                db.session.commit()
            except Exception:
                db.session.rollback()
                app.logger.exception("Failed to save goal history (calculation itself still succeeded)")

            return jsonify(result)

        except ValidationError as e:
            return jsonify({"error": str(e)}), 400
        except ZeroDivisionError:
            return jsonify({"error": "Target duration cannot be zero."}), 400
        except Exception:
            app.logger.exception("calculate_goal failed")
            return jsonify({"error": "Something went wrong while calculating your goal."}), 500

    # ---------- Notifications API ----------

    @app.route("/api/notifications")
    @login_required
    def notifications():
        user = current_user()

        notifications = []

        # --------------------------------------------------------
        # 1. Welcome notification
        # --------------------------------------------------------
        notifications.append({
            "id": "welcome",
            "icon": "👋",
            "title": "Welcome to Finance Advisor",
            "message": f"Hi {user.name}, your financial dashboard is ready.",
            "type": "info"
        })

        # --------------------------------------------------------
        # 2. Notifications based on the user's latest finances
        # --------------------------------------------------------
        record = latest_financial_record(user.id)

        if record:
            if record.income > 0:
                savings_percentage = (record.savings / record.income) * 100

                if savings_percentage >= 20:
                    notifications.append({
                        "id": "savings-good",
                        "icon": "💰",
                        "title": "Good Savings Progress",
                        "message": (
                            f"You are currently saving about "
                            f"{savings_percentage:.1f}% of your income."
                        ),
                        "type": "success"
                    })
                elif savings_percentage > 0:
                    notifications.append({
                        "id": "savings-reminder",
                        "icon": "💡",
                        "title": "Savings Reminder",
                        "message": (
                            f"Your current savings rate is "
                            f"{savings_percentage:.1f}%. Consider reviewing your expenses."
                        ),
                        "type": "warning"
                    })

            if record.income > 0 and record.total_expense > record.income * 0.8:
                notifications.append({
                    "id": "high-expense",
                    "icon": "⚠️",
                    "title": "High Expense Alert",
                    "message": "Your expenses are above 80% of your recorded income.",
                    "type": "warning"
                })

            if record.debt > 0:
                notifications.append({
                    "id": "debt",
                    "icon": "💳",
                    "title": "Debt Reminder",
                    "message": (
                        f"Your current recorded debt is ₹{record.debt:,.0f}."
                    ),
                    "type": "warning"
                })

        # --------------------------------------------------------
        # 3. Notifications from recent prediction history
        # --------------------------------------------------------
        recent_history = (
            PredictionHistory.query
            .filter_by(user_id=user.id)
            .order_by(PredictionHistory.created_at.desc())
            .limit(5)
            .all()
        )

        for item in recent_history:

            if item.prediction_type == "Expense Prediction":
                notifications.append({
                    "id": f"history-{item.id}",
                    "icon": "📈",
                    "title": "Expense Prediction Available",
                    "message": f"Your predicted expense is {item.result}.",
                    "type": "info"
                })

            elif item.prediction_type == "Financial Status":
                notifications.append({
                    "id": f"history-{item.id}",
                    "icon": "🛡️",
                    "title": "Financial Status Updated",
                    "message": f"Your latest financial status is {item.result}.",
                    "type": "info"
                })

            elif item.prediction_type == "Goal Planner":
                notifications.append({
                    "id": f"history-{item.id}",
                    "icon": "🎯",
                    "title": "Goal Planner Update",
                    "message": f"Your latest goal analysis is {item.result}.",
                    "type": "info"
                })

        # Keep the dropdown compact.
        notifications = notifications[:8]

        return jsonify({
            "notifications": notifications,
            "count": len(notifications)
        })


    @app.errorhandler(404)
    def not_found(e):
        return render_template("404.html"), 404

    @app.errorhandler(500)
    def server_error(e):
        return render_template("500.html"), 500


# ---------- Validation helpers ----------

class ValidationError(Exception):
    pass


def validate_positive_number(value, field_name):
    try:
        num = float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{field_name} must be a valid number.")
    if num <= 0:
        raise ValidationError(f"{field_name} must be greater than zero.")
    if num > 100000000:
        raise ValidationError(f"{field_name} value seems unrealistically large.")
    return num


def validate_non_negative_number(value, field_name, allow_zero=True):
    try:
        num = float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{field_name} must be a valid number.")
    if num < 0:
        raise ValidationError(f"{field_name} cannot be negative.")
    if num > 100000000:
        raise ValidationError(f"{field_name} value seems unrealistically large.")
    return num


def build_dashboard_insights(user, record, status_label):
    insights = []
    if not record:
        return ["Add your financial details to see personalized insights."]

    if record.total_expense > user.monthly_income * 0.8:
        insights.append("Your expenses may increase next month.")
    if status_label != "Unknown":
        insights.append(f"Your current financial condition is {status_label}.")
    if record.savings > 0:
        insights.append("You are on track to achieve your savings goal.")
    if record.entertainment > record.income * 0.1:
        insights.append("Consider reducing entertainment spending.")
    if not insights:
        insights.append("Keep tracking your spending regularly for better insights.")
    return insights


def build_expense_trend(user_id):
    """Builds last-6-month actual vs predicted trend from stored records,
    padding with clearly-labeled demo data if there isn't enough history."""
    records = (
        FinancialRecord.query.filter_by(user_id=user_id)
        .order_by(FinancialRecord.date.asc())
        .all()
    )

    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]

    if len(records) >= 6:
        recent = records[-6:]
        actual = [r.total_expense for r in recent]
        predicted = [round(a * 1.03, 2) for a in actual]
        is_demo = False
    else:
        # Sample/demo data clearly identified as such in the UI.
        actual = [23000, 24500, 25800, 26900, 27500, 28000]
        predicted = [22000, 23400, 24900, 26100, 27000, 29200]
        is_demo = True

    return {"labels": months, "actual": actual, "predicted": predicted, "is_demo": is_demo}


app = create_app()

if __name__ == "__main__":
    # use_reloader=False avoids a known Windows issue where Werkzeug's
    # file-watching reloader spawns a background subprocess that can be
    # silently killed (often by antivirus/Defender), causing the server to
    # exit right after printing its startup banner. Debug mode (tracebacks
    # in the browser) stays on either way.
    app.run(debug=True, port=5000, use_reloader=False)
